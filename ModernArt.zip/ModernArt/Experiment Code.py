    ## FROM:
    # https://github.com/FinnLandLab/Psychopy-Templates/blob/master/response_tracking_and_output_generation/response_tracking_and_output_generation.py
    # https://github.com/FinnLandLab/Psychopy-Templates/blob/master/reading_csv_multiple_stim/reading_CSV_files.py
    # https://github.com/FinnLandLab/Psychopy-Templates/blob/master/psychopy_basic_experiment_demo/Main.py




from psychopy import data, core, visual, event, gui
import time
import os
import numpy as np
from random import *
import random

import sys
from time import sleep


#Ensure that relative paths start from the same directory as this script
directory = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
os.chdir(directory)


# Store info about the experiment session
expName = 'Modern_Art'  # from the Builder filename that created this script
expInfo = {'participant':'', 'age':'', 'sex':'', 'handedness':'','phase':'train', 'set_input':'def'} ##### TO MAKE FIELDS BLANK, JUST HAVE THEM GO :''
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)

if not dlg.OK:
    core.quit()

expInfo['date'] = data.getDateStr()

### create base filename to store data ###
out_filename = "data/%03d-%s-%s.csv" %(int(expInfo['participant']), expInfo['phase'], expInfo['date'])


# experiment handler
thisExp = data.ExperimentHandler(name=expName,
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=False, saveWideText=True,
    dataFileName=out_filename)
# save pickle is used to save the .psydat file (not really needed)


endExpNow = False



### monitor & mouse parameters ###
monitor = 'iMac'
monitorX = 1920.00
monitorY = 1080.00
win = visual.Window(size = (monitorX, monitorY), fullscr = True, units = 'norm', monitor = monitor, colorSpace = 'rgb', color = 'white')
win.mouseVisible = False



# define feedback text (@ trial level)
correct_Feedback = visual.TextStim(win = win, units = 'norm', colorSpace= 'rgb', color = 'green', font = 'Verdana',
 text = 'Great!', pos = (0,0), height = 0.25)
incorrect_Feedback = visual.TextStim(win = win, units = 'norm', colorSpace= 'rgb', color = 'red', font = 'Verdana',
 text = 'Oops!', pos = (0,0), height = 0.25)
faster_Feedback = visual.TextStim(win = win, units = 'norm', colorSpace= 'rgb', color = 'red', font = 'Verdana',
 text = 'Too slow!!', pos = (0,0), height = 0.25)


# define fixation cross text
fixcross = visual.TextStim(win=win, units = 'norm', name='fixcross',
    text='+', font='Verdana', pos=[0, 0], height=0.1, color='black', colorSpace='rgb', depth=0.0)


# define thank you screen text
thanks_end = visual.TextStim(win=win, name = 'thanks_end',
    text = "Thank you for your participation!",
    font='Verdana',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0,
    color='black', colorSpace='rgb', opacity=1,
    depth=0.0);


# define block avg feedback images: separate for above vs below 90%
block_feedback_above = visual.ImageStim(win = win, image = 'Other_Images/Above.PNG',
 name = 'block_feedback_above', pos = (0,0), size = (2,2))
block_feedback_below = visual.ImageStim(win = win, image = 'Other_Images/Below.PNG',
 name = 'block_feedback_below', pos = (0,0), size = (2,2))



# design instructions image list #
instructions_list = ['Instr_img1.png', 'Instr_img2.png', 'Instr_img3.png', 'Instr_img4.png', 'Instr_img5.png', 'Instr_img6.png']
# make instr screen?
full_image = visual.ImageStim(win=win, size=2, pos=[0, 0])



# present instruction screens
for instruction in instructions_list:
    full_image.setImage('instructions/%s' % instruction) ### THE FIRST 'instructions' is the folder
    full_image.draw()
    win.flip()
    while True:
        time.sleep(1)  # Reduces amount of resources used
        if event.getKeys(keyList=['escape', 'esc']):
            core.quit()
        elif event.getKeys(keyList=['space']):
            break



# randomly assign a stimuli set
numlist_asstrings = ['1','2','3','4','5','6']

if expInfo["set_input"] == 'def':
    set = (random.choice(numlist_asstrings))
else:
    set = expInfo["set_input"]

#set = 1
#set = randint(1, 6)
print set

if set == '1': in_filename = 'Images_AB/Stim_List_AB.csv'
elif set == '2': in_filename = 'Images_AC/Stim_List_AC.csv'
elif set == '3': in_filename = 'Images_BC/Stim_List_BC.csv'
elif set == '4': in_filename = 'Images_BD/Stim_List_BD.csv'
elif set == '5': in_filename = 'Images_CD/Stim_List_CD.csv'
elif set == '6': in_filename = 'Images_DA/Stim_List_DA.csv'
else:
    win.close
    core.quit

print in_filename
#### NEED TO save 'set' for each trial

'''
set = random.integer(1-6)           OR          make an input for set?
if set = 1 --> input file location
    set = 2
    set = 3
    set = 4

** should categories of stim be equally an 'f' and 'j' response across sets?
AB  AC  BC  BD  CD  DA


'''




'''
TIMING: DONE
- stim visible for 750ms
- blank screen delay for 250ms (response permitted)
- feedback 300ms

** fixation cross before next block starts (500ms) **
'''

# define countdown to starting
def waiting(sec):
    while sec > 0:
            sys.stdout.write(str(sec) + '     \r')
            sec_num = visual.TextStim(win=win, units = 'norm', colorSpace = 'rgb', color = 'black', font = 'Verdana', name = 'sec_num', text = sec, pos = (0,0), height = .15)
            sec_num.draw()
            win.flip()
            core.wait(1)
            sec -= 1
#            sleep(1)



# prep a counter for block number; initial value is one
block_num = 1
block_num = float(block_num)

# prep block average calculation
block_avg = 0
block_avg  = float(block_avg)


# start countdown before trials begin
waiting(5)

while (block_avg < 0.9) & (block_num < 36): # THIS IS WHERE YOU CAN SET MAX BLOCK NUM (ex. set to 3 means will run 2 blocks)

    # put trial handler etc INSIDE while loop
    ## trial handler
    trial_handler = data.TrialHandler(nReps=1, method='random',
        extraInfo=None, trialList=data.importConditions(in_filename),
        seed=None, name='')

    # add trial handler to exp handler
    thisExp.addLoop(trial_handler)

    # Used to keep track of response for a trial
    response = event.BuilderKeyResponse()

    # blank image to draw over
    blank_img = visual.ImageStim(win = win, image = 'Images_AB/A1.PNG', name = 'Blank_img', pos = (0,0), size = (0.48,.8))

    # call up correct answer from column in csv
    corAns=trial_handler.trialList[0].corAns
    #print(corAns)


    # make empty list for NUMERICAL responses to append (to sum)
    resp_list = []

    # go through every trial/row in the CSV
    for trial in trial_handler:

        corAns = trial.corAns


        # set image stim based on csv file row values
        blank_img.setImage(trial['stimuli'])

        # draw on screen
        blank_img.draw()
        win.flip()

        # Reset response timer to start counting from 0
        response.clock.reset()


        # Clear all pressed keys before starting next trial
        # This is used just in case user pressed a key in between trials
        event.clearEvents()

        found = False
        timely_response = False
        response.nums=[]

        # Keep displaying text until response (escape, f or j)
        while response.clock.getTime() <.750:
            theseKeys = event.getKeys(keyList=['j','f', 'esc', 'escape'])
            if(len(theseKeys)>0 and not found):
                response.keys=theseKeys[0]
                response.RT=response.clock.getTime()
                found = True


                if(((response.keys=='f') and (corAns=='f'))) or ((response.keys=='j') and (corAns=='j')):
                    correct_Feedback.draw()
                    win.flip()
                    timely_response=True
                    response.nums=1

                elif(((response.keys=='f') and (corAns=='j'))) or ((response.keys=='j') and (corAns=='f')):
                    incorrect_Feedback.draw()
                    win.flip()
                    timely_response=True
                    response.nums=0

                elif(response.keys=='esc'):
                    win.close
                    core.quit()
                    endExpNow = True

                elif(response.keys=='escape'):
                    win.close
                    core.quit()
                    endExpNow = True

    # for slow responses (still in response window)
        while response.clock.getTime() < 1 and not timely_response:
            win.flip(clearBuffer=True)


            theseKeys = event.getKeys(keyList=['j','f', 'esc', 'escape'])
            if(len(theseKeys)>0 and not found):
                response.keys=theseKeys[0]
                response.RT=response.clock.getTime()
                found = True

                if(((response.keys=='f') and (corAns=='f'))) or ((response.keys=='j') and (corAns=='j')):
                    correct_Feedback.draw()
                    win.flip()
                    response.nums=1

                elif(((response.keys=='f') and (corAns=='j'))) or ((response.keys=='j') and (corAns=='f')):
                    incorrect_Feedback.draw()
                    win.flip()
                    response.nums=0

                elif(response.keys=='esc'):
                    win.close
                    core.quit()
                    endExpNow = True

                elif(response.keys=='escape'):
                    win.close
                    core.quit()
                    endExpNow = True

                core.wait(.300) # this is not the ISI - sets how long feedback on screen

        if not found:
            response.keys=0.0
            #response.keys=np.nan

            response.RT=0.0
            #response.RT=np.nan

            timely_response = False
            faster_Feedback.draw()
            win.flip()

            response.nums=0.0
            #response.nums=np.nan



        core.wait(.300) # this is not the ISI - sets how long feedback on screen
        win.clearBuffer()

        ### calculate mean for block
        #block_mean = response.keys()

        # Add the response and response time to the ExperimentHandler which will add it to the output file for the
        # given trial.
        thisExp.addData('my_response', response.keys)
        thisExp.addData('my_response_time', response.RT)
        thisExp.addData('acc_num', response.nums)
        thisExp.addData('block_num', block_num)
        thisExp.addData('set',set)
        thisExp.addData('in_filename', in_filename)


        resp_list.append(response.nums)

        # Inform the ExperimentHandler that you are moving on to the next trial
        # This is required for the output file generation
        thisExp.nextEntry()


    # add 1 to block num counter
    block_num = (block_num +1 )
    #print(block_num)



    ### NEED TO ADD BLOCK FEEDBACK ####

    # caculate & display block average accuracy
    print(resp_list) # - list of all trial responses
    resp_mean = np.nanmean(resp_list) # - calculate mean of that list
    print(resp_mean) # - mean of that list
    block_avg = resp_mean
    as_prop = block_avg*100

    # define numberical block feedback text items
    block_feedback_belowtxt = visual.TextStim(win=win, units = 'norm', colorSpace = 'rgb', color = 'black', font = 'Verdana',
     name = 'block_feedback', text = "You got %s %% correct" % (as_prop), pos = (0,0), height = .1)
    block_feedback_abovetxt = visual.TextStim(win=win, units = 'norm', colorSpace = 'rgb', color = 'black', font = 'Verdana',
     name = 'block_feedback', text = "You got %s %% correct" % (as_prop), pos = (0,0), height = .1)

    # define rest screen
    rest_screen = visual.TextStim(win=win, units = 'norm', colorSpace = 'rgb', color = 'black', font = 'Verdana',
     name = 'rest_screen', text = "Press space to begin", pos = (0,0), height = .1)



    # update list of items (resp_list)
    resp_list = []

    '''
    - need to actually make a text image that displays acc to participant
    - also a list of acc on each block
    - then cutoff for 90% acuracy
    '''

    # draw fixation cross
    fixcross.draw()
    win.flip()
    core.wait(.5) # this is the fixation cross duration

    '''
    need to display accuracy - maybe 5 seconds?
    '''
    if block_avg < .9:
        block_feedback_below.draw()
        win.flip()
        core.wait(2)
        block_feedback_belowtxt.draw()
        win.flip()
        core.wait(5)
    else:
        block_feedback_above.draw()
        win.flip()
        core.wait(2)
        block_feedback_abovetxt.draw()
        win.flip()
        core.wait(5)

    # have a rest screen - end via spacebar
    win.clearBuffer()
    rest_screen.draw()
    win.flip()
    while True:
        time.sleep(1)  # Reduces amount of resources used
        if event.getKeys(keyList=['escape', 'esc']):
            core.quit()
        elif event.getKeys(keyList=['space']):
            break

'''                                                                     MAYBE NOT -LOOKS LIKE ALREADY BEING SAVED (at trial level only?)
# add this stuff to record data from last block (that reaches >90%)
    # caculate & display block average accuracy
    print(resp_list) # - list of all trial responses
    resp_mean = np.nanmean(resp_list) # - calculate mean of that list
    print(resp_mean) # - mean of that list
    block_avg = resp_mean
'''


# this should run after 90% accuracy achieved in a block

### show thank you screen ###
thanks_end.draw()
win.flip()
core.wait(5) # how long thank-you screen appears
# save data to csv
#thisExp.saveAsWideText(out_filename + '.csv')

#s.quit()
win.close()
core.quit()
